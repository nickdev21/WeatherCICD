import styled from 'styled-components';

export const MealPreSafeAreaView = styled.SafeAreaView`
  flex: 1;
  /* background-color: #f5f5f5; */
  `;
