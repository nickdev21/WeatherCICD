import styled from 'styled-components';

export const MealPreSafeAreaView = styled.SafeAreaView`
  flex: 1;
  /* padding: 10px, */
  /* margin: 0 0 10% 0; */
  /* background-color: #f5f5f5; */
  `;
